/*
 * fsr_sensor.h
 *
 *  Created on: 05.07.2015
 *      Author: nico
 */

#ifndef FSR_SENSOR_H_
#define FSR_SENSOR_H_

bool get_fsr_value();
void init_fsr_values();

#endif /* FSR_SENSOR_H_ */
